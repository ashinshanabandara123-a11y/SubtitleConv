package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object AssFormat {
    data class ParsedHeader(
        val fields: List<String>,
        val startIndex: Int,
        val endIndex: Int,
        val textIndex: Int
    )

    fun parse(content: String): List<Cue> {
        val clean = stripBom(content)
        val lines = clean.lines()
        var inEvents = false
        var header: ParsedHeader? = null
        val cues = mutableListOf<Cue>()

        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("[") && line.endsWith("]")) {
                inEvents = line.equals("[Events]", ignoreCase = true)
                continue
            }
            if (!inEvents) continue

            if (line.startsWith("Format:", ignoreCase = true)) {
                val rawFields = line.substringAfter(":").split(",").map { it.trim().lowercase() }
                val startIdx = rawFields.indexOf("start")
                val endIdx = rawFields.indexOf("end")
                val textIdx = rawFields.indexOf("text")
                if (startIdx != -1 && endIdx != -1 && textIdx != -1) {
                    header = ParsedHeader(rawFields, startIdx, endIdx, textIdx)
                }
                continue
            }

            if (line.startsWith("Dialogue:", ignoreCase = true)) {
                val h = header ?: defaultHeader()
                val payload = line.substringAfter(":").trimStart()
                val parts = payload.split(",", limit = h.fields.size)
                if (parts.size <= h.textIndex) continue
                val start = parseAssTime(parts[h.startIndex].trim())
                val end = parseAssTime(parts[h.endIndex].trim())
                val text = parts[h.textIndex].trim()
                if (start >= 0 && end >= 0 && text.isNotBlank()) cues.add(Cue(start, end, text))
            }
        }
        return cues.sortedBy { it.startMs }
    }

    fun serialize(cues: List<Cue>): String {
        val sb = StringBuilder()
        sb.append("[Script Info]\n")
        sb.append("ScriptType: v4.00+\n")
        sb.append("PlayResX: 384\n")
        sb.append("PlayResY: 288\n\n")
        sb.append("[V4+ Styles]\n")
        sb.append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        sb.append("Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1\n\n")
        sb.append("[Events]\n")
        sb.append("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        cues.sortedBy { it.startMs }.forEach { cue ->
            sb.append("Dialogue: 0,")
            sb.append(formatAssTime(cue.startMs)).append(',')
            sb.append(formatAssTime(cue.endMs)).append(',')
            sb.append("Default,,0,0,0,,")
            sb.append(cue.text.replace("\n", "\\N")).append('\n')
        }
        return sb.toString()
    }

    private fun defaultHeader(): ParsedHeader {
        val fields = listOf("layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text")
        return ParsedHeader(fields, 1, 2, 9)
    }

    private fun parseAssTime(t: String): Long {
        val regex = Regex("""(\d+):(\d{2}):(\d{2})[.](\d{1,3})""")
        val m = regex.find(t) ?: return -1
        val h = m.groupValues[1].toLong()
        val min = m.groupValues[2].toLong()
        val sec = m.groupValues[3].toLong()
        val frac = m.groupValues[4].padEnd(3, '0').toLong()
        return h * 3600000 + min * 60000 + sec * 1000 + frac
    }

    private fun formatAssTime(ms: Long): String {
        val h = ms / 3600000
        val m = (ms % 3600000) / 60000
        val s = (ms % 60000) / 1000
        val cs = (ms % 1000) / 10
        return "%d:%02d:%02d.%02d".format(h, m, s, cs)
    }

    private fun stripBom(text: String): String =
        if (text.startsWith("\uFEFF")) text.substring(1) else text
}
