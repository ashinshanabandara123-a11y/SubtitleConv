package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object MicroDvdFormat {
    private val lineRegex = Regex("""\{(\d+)\}\{(\d+)\}(.*)""")

    fun parse(content: String, fps: Double = 25.0): List<Cue> {
        val cues = mutableListOf<Cue>()
        val clean = content.removePrefix("\uFEFF")
        for (line in clean.lines()) {
            val m = lineRegex.matchEntire(line.trim()) ?: continue
            val startFrame = m.groupValues[1].toLong()
            val endFrame = m.groupValues[2].toLong()
            val text = m.groupValues[3].replace("|", "\n")
            if (text.isNotBlank()) cues.add(Cue(frameToMs(startFrame, fps), frameToMs(endFrame, fps), text))
        }
        return cues.sortedBy { it.startMs }
    }

    fun serialize(cues: List<Cue>, fps: Double = 25.0): String {
        val sb = StringBuilder()
        cues.sortedBy { it.startMs }.forEach { cue ->
            sb.append('{').append(msToFrame(cue.startMs, fps)).append('}')
            sb.append('{').append(msToFrame(cue.endMs, fps)).append('}')
            sb.append(cue.text.replace("\n", "|")).append('\n')
        }
        return sb.toString()
    }

    private fun frameToMs(frame: Long, fps: Double): Long = (frame / fps * 1000.0).toLong()
    private fun msToFrame(ms: Long, fps: Double): Long = (ms / 1000.0 * fps).toLong()
}
