package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue
import com.bingle.subtitleconv.model.SubtitleFormat
import java.io.InputStream

object SubtitleConverter {
    fun detectFormat(content: String): SubtitleFormat {
        val clean = content.removePrefix("\uFEFF")
        return when {
            clean.contains("[Script Info]") || clean.contains("[V4+ Styles]") || clean.contains("Dialogue:") ->
                if (clean.contains("ScriptType: v4.00+")) SubtitleFormat.ASS else SubtitleFormat.SSA
            clean.startsWith("WEBVTT") -> SubtitleFormat.VTT
            clean.contains("-->") && clean.contains(Regex("""\d{2}:\d{2}:\d{2},\d{3}""")) -> SubtitleFormat.SRT
            clean.contains(Regex("""\{\d+\}\{\d+\}""")) -> SubtitleFormat.MICRODVD
            else -> SubtitleFormat.SRT
        }
    }

    fun parse(inputStream: InputStream, hint: SubtitleFormat? = null): List<Cue> {
        val text = decodeBytes(inputStream.readBytes())
        val format = hint ?: detectFormat(text)
        return when (format) {
            SubtitleFormat.SRT -> SrtFormat.parse(text)
            SubtitleFormat.VTT -> VttFormat.parse(text)
            SubtitleFormat.ASS, SubtitleFormat.SSA -> AssFormat.parse(text)
            SubtitleFormat.MICRODVD -> MicroDvdFormat.parse(text)
        }
    }

    fun serialize(cues: List<Cue>, format: SubtitleFormat): String =
        when (format) {
            SubtitleFormat.SRT -> SrtFormat.serialize(cues)
            SubtitleFormat.VTT -> VttFormat.serialize(cues)
            SubtitleFormat.ASS, SubtitleFormat.SSA -> AssFormat.serialize(cues)
            SubtitleFormat.MICRODVD -> MicroDvdFormat.serialize(cues)
        }

    private fun decodeBytes(bytes: ByteArray): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        return String(bytes, Charsets.UTF_8)
    }
}
