package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object VttFormat {
    private val timeRegex = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})\.(\d{3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})\.(\d{3})"""
    )

    fun parse(content: String): List<Cue> {
        val cues = mutableListOf<Cue>()
        val clean = content.removePrefix("\uFEFF")
        val blocks = clean.split(Regex("""\r?\n\s*\r?\n"""))
        for (block in blocks) {
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.isEmpty() || lines[0].startsWith("WEBVTT")) continue
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: continue
            val match = timeRegex.find(timeLine) ?: continue
            val start = toMs(match.groupValues[1], match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val end = toMs(match.groupValues[5], match.groupValues[6], match.groupValues[7], match.groupValues[8])
            val textStart = lines.indexOf(timeLine) + 1
            val text = lines.drop(textStart).joinToString("\n")
            if (text.isNotBlank()) cues.add(Cue(start, end, text))
        }
        return cues.sortedBy { it.startMs }
    }

    fun serialize(cues: List<Cue>): String {
        val sb = StringBuilder("WEBVTT\n\n")
        cues.sortedBy { it.startMs }.forEach { cue ->
            sb.append(formatTime(cue.startMs)).append(" --> ").append(formatTime(cue.endMs)).append('\n')
            sb.append(cue.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun toMs(h: String, m: String, s: String, ms: String): Long =
        h.toLong() * 3600000 + m.toLong() * 60000 + s.toLong() * 1000 + ms.toLong()

    private fun formatTime(ms: Long): String {
        val h = ms / 3600000
        val m = (ms % 3600000) / 60000
        val s = (ms % 60000) / 1000
        val millis = ms % 1000
        return "%02d:%02d:%02d.%03d".format(h, m, s, millis)
    }
}
