# SubtitleConv

Android Studio project for converting and editing subtitle files.

## Supported formats
- SubRip (`.srt`)
- Advanced SubStation Alpha (`.ass`)
- SubStation Alpha (`.ssa`)
- WebVTT (`.vtt`)
- MicroDVD (`.sub`, assumed 25 FPS)

## Build
1. Extract this ZIP.
2. Open the `SubtitleConv` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Requirements: Android Studio with JDK 17 and Android SDK Platform 34.

Package: `com.bingle.subtitleconv`
Minimum Android: 7.0 (API 24)
