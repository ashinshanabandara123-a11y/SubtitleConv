# SubtitleConv — Android Studio project

SubtitleConv is a Kotlin + Jetpack Compose subtitle converter/editor. It supports importing and exporting SRT, ASS, SSA, VTT, and MicroDVD subtitle files, editing individual cues, clearing the cue list, and light/dark mode.

## Build

- Open this folder in Android Studio (Hedgehog or newer recommended).
- Allow Gradle sync and install Android SDK Platform 34 if prompted.
- Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
- The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Toolchain: AGP 8.2.2, Kotlin 1.9.22, Gradle 8.2, JDK 17, Compose compiler 1.5.8, compileSdk 34, minSdk 24.

The uploaded SC artwork is installed as both the standard and round launcher icon in all density buckets.

## Note about this archive

This archive contains the complete Android Studio project source. A compiled APK is not included because the packaging environment does not have the Android SDK or Gradle installed. The Gradle wrapper distribution settings are included; Android Studio will download the required Gradle distribution during sync.
