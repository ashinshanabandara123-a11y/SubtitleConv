@echo off
set APP_HOME=%~dp0
set GRADLE_VERSION=8.2
set GRADLE_HOME_DIR=%USERPROFILE%\.gradle\subtitleconv-gradle\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME_DIR%\bin\gradle.bat" (
  echo Please download Gradle 8.2 from https://services.gradle.org/distributions/gradle-8.2-bin.zip
  echo Extract it to %GRADLE_HOME_DIR%
  exit /b 1
)
call "%GRADLE_HOME_DIR%\bin\gradle.bat" -p "%APP_HOME%" %*
