package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object AssFormat {
    private data class Header(val fields: List<String>, val start: Int, val end: Int, val text: Int)
    fun parse(content: String): List<Cue> {
        var inEvents = false
        var header: Header? = null
        val cues = mutableListOf<Cue>()
        for (raw in content.removePrefix("\uFEFF").lines()) {
            val line = raw.trim(); if (line.isEmpty()) continue
            if (line.startsWith("[") && line.endsWith("]")) { inEvents = line.equals("[Events]", true); continue }
            if (!inEvents) continue
            if (line.startsWith("Format:", true)) {
                val f = line.substringAfter(':').split(',').map { it.trim().lowercase() }
                val s=f.indexOf("start"); val e=f.indexOf("end"); val t=f.indexOf("text")
                if (s>=0 && e>=0 && t>=0) header=Header(f,s,e,t)
            } else if (line.startsWith("Dialogue:", true)) {
                val h=header ?: Header(listOf("layer","start","end","style","name","marginl","marginr","marginv","effect","text"),1,2,9)
                val p=line.substringAfter(':').trimStart().split(',', limit=h.fields.size)
                if (p.size<=h.text) continue
                val s=parseTime(p[h.start].trim()); val e=parseTime(p[h.end].trim()); val text=p[h.text].trim()
                if (s>=0 && e>=0 && text.isNotBlank()) cues.add(Cue(s,e,text))
            }
        }
        return cues.sortedBy { it.startMs }
    }
    fun serialize(cues: List<Cue>): String = buildString {
        append("[Script Info]\nScriptType: v4.00+\nPlayResX: 384\nPlayResY: 288\n\n[V4+ Styles]\n")
        append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        append("Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1\n\n[Events]\n")
        append("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        cues.sortedBy { it.startMs }.forEach { c -> append("Dialogue: 0,").append(fmt(c.startMs)).append(',').append(fmt(c.endMs)).append(",Default,,0,0,0,,").append(c.text.replace("\n","\\N")).append('\n') }
    }
    private fun parseTime(t:String):Long { val m=Regex("""(\d+):(\d{2}):(\d{2})[.](\d{1,3})""").find(t)?:return -1; return m.groupValues[1].toLong()*3600000+m.groupValues[2].toLong()*60000+m.groupValues[3].toLong()*1000+m.groupValues[4].padEnd(3,'0').toLong() }
    private fun fmt(ms:Long)="%d:%02d:%02d.%02d".format(ms/3600000,(ms%3600000)/60000,(ms%60000)/1000,(ms%1000)/10)
}
