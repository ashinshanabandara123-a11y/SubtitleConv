package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object MicroDvdFormat {
    private val lineRegex=Regex("""\{(\d+)\}\{(\d+)\}(.*)""")
    fun parse(content:String,fps:Double=25.0):List<Cue> = content.removePrefix("\uFEFF").lines().mapNotNull { line ->
        val m=lineRegex.matchEntire(line.trim())?:return@mapNotNull null
        val text=m.groupValues[3].replace("|","\n"); if(text.isBlank()) null else Cue(frameToMs(m.groupValues[1].toLong(),fps),frameToMs(m.groupValues[2].toLong(),fps),text)
    }.sortedBy { it.startMs }
    fun serialize(cues:List<Cue>,fps:Double=25.0):String=buildString { cues.sortedBy { it.startMs }.forEach { c -> append('{').append(msToFrame(c.startMs,fps)).append('}').append('{').append(msToFrame(c.endMs,fps)).append('}').append(c.text.replace("\n","|")).append('\n') } }
    private fun frameToMs(frame:Long,fps:Double)=(frame/fps*1000.0).toLong()
    private fun msToFrame(ms:Long,fps:Double)=(ms/1000.0*fps).toLong()
}
