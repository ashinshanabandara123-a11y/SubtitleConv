package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object VttFormat {
    private val timeRegex = Regex("""(\d{1,2}):(\d{2}):(\d{2})\.(\d{3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})\.(\d{3})""")
    fun parse(content: String): List<Cue> {
        val cues = mutableListOf<Cue>()
        for (block in content.removePrefix("\uFEFF").split(Regex("""\r?\n\s*\r?\n"""))) {
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.isEmpty() || lines[0].startsWith("WEBVTT")) continue
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: continue
            val m = timeRegex.find(timeLine) ?: continue
            fun t(i: Int) = m.groupValues[i].toLong()
            val start = t(1)*3600000+t(2)*60000+t(3)*1000+t(4)
            val end = t(5)*3600000+t(6)*60000+t(7)*1000+t(8)
            val text = lines.drop(lines.indexOf(timeLine)+1).joinToString("\n")
            if (text.isNotBlank()) cues.add(Cue(start,end,text))
        }
        return cues.sortedBy { it.startMs }
    }
    fun serialize(cues: List<Cue>): String = buildString {
        append("WEBVTT\n\n")
        cues.sortedBy { it.startMs }.forEach { c -> append(time(c.startMs)).append(" --> ").append(time(c.endMs)).append('\n').append(c.text).append("\n\n") }
    }
    private fun time(ms: Long) = "%02d:%02d:%02d.%03d".format(ms/3600000,(ms%3600000)/60000,(ms%60000)/1000,ms%1000)
}
