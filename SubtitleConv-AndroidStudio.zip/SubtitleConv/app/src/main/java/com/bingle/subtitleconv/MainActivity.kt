package com.bingle.subtitleconv

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bingle.subtitleconv.converter.SubtitleConverter
import com.bingle.subtitleconv.model.Cue
import com.bingle.subtitleconv.model.SubtitleFormat
import com.bingle.subtitleconv.theme.SubtitleConvTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContent {
        var dark by rememberSaveable { mutableStateOf(isSystemInDarkTheme()) }
        SubtitleConvTheme(darkTheme=dark) { SubtitleConvApp(darkTheme=dark,onToggleDarkTheme={dark=it}) }
    } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubtitleConvApp(darkTheme:Boolean,onToggleDarkTheme:(Boolean)->Unit) {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    val drawer= rememberDrawerState(DrawerValue.Closed)
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var outputFormat by rememberSaveable { mutableStateOf(SubtitleFormat.SRT) }
    var fileName by remember { mutableStateOf("(no file loaded)") }
    var editingCue by remember { mutableStateOf<Cue?>(null) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }
    val snackbar= remember { SnackbarHostState() }
    LaunchedEffect(snackbarMessage) { snackbarMessage?.let { snackbar.showSnackbar(it); snackbarMessage=null } }

    val openLauncher= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri:Uri? ->
        if(uri!=null) scope.launch { try {
            val name=queryDisplayName(context,uri)?:uri.lastPathSegment?:"unknown"
            val parsed=withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { SubtitleConverter.parse(it) }?:emptyList() }
            if(parsed.isEmpty()) snackbarMessage="Read failed: no cues found in $name" else {
                cues=parsed; fileName=name; snackbarMessage="Loaded ${parsed.size} cues from $name"
            }
        } catch(e:Exception) { snackbarMessage="Read failed: ${e.message?:e.javaClass.simpleName}" } }
    }
    val saveLauncher= rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri:Uri? ->
        if(uri!=null) scope.launch { try {
            val output=withContext(Dispatchers.IO) { SubtitleConverter.serialize(cues,outputFormat) }
            withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { it.write(output.toByteArray(Charsets.UTF_8)) } }
            snackbarMessage="Saved ${cues.size} cues as ${outputFormat.displayName}"
        } catch(e:Exception) { snackbarMessage="Save failed: ${e.message}" } }
    }
    fun openFile()=openLauncher.launch(arrayOf("*/*"))
    fun saveFile()=saveLauncher.launch("output.${outputFormat.extension}")

    ModalNavigationDrawer(drawerState=drawer,drawerContent={ ModalDrawerSheet {
        Spacer(Modifier.height(24.dp)); Text("SubtitleConv",style=MaterialTheme.typography.headlineSmall,modifier=Modifier.padding(horizontal=28.dp))
        Text("v3",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(horizontal=28.dp,vertical=4.dp))
        Spacer(Modifier.height(24.dp))
        NavigationDrawerItem(icon={Icon(Icons.Default.OpenInNew,null)},label={Text("Open subtitle file")},selected=false,onClick={scope.launch { drawer.close() };openFile()})
        NavigationDrawerItem(icon={Icon(Icons.Default.Delete,null)},label={Text("Clear all cues")},selected=false,onClick={scope.launch { drawer.close() };cues=emptyList();fileName="(no file loaded)";snackbarMessage="Cues cleared"})
        HorizontalDivider(Modifier.padding(horizontal=28.dp,vertical=8.dp))
        Text("Output format",style=MaterialTheme.typography.labelLarge,modifier=Modifier.padding(horizontal=28.dp,vertical=8.dp))
        SubtitleFormat.entries.forEach { fmt -> NavigationDrawerItem(label={Text(fmt.displayName)},selected=outputFormat==fmt,onClick={outputFormat=fmt;scope.launch { drawer.close() }},modifier=Modifier.padding(horizontal=12.dp)) }
        HorizontalDivider(Modifier.padding(horizontal=28.dp,vertical=8.dp))
        NavigationDrawerItem(icon={Icon(if(darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,null)},label={Text(if(darkTheme) "Light mode" else "Dark mode")},selected=false,onClick={onToggleDarkTheme(!darkTheme)})
        Spacer(Modifier.height(24.dp)); Text("made by bingle",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(28.dp))
    } }) {
        Scaffold(topBar={ TopAppBar(title={Text("SubtitleConv")},navigationIcon={IconButton(onClick={scope.launch { drawer.open() }}) { Icon(Icons.Default.Menu,"Open drawer") }},actions={
            IconButton(onClick={openFile}) { Icon(Icons.Default.OpenInNew,"Open file") }
            IconButton(onClick={saveFile},enabled=cues.isNotEmpty()) { Icon(Icons.Default.Save,"Save") }
        }) },snackbarHost={SnackbarHost(snackbar)}) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
                Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(fileName,style=MaterialTheme.typography.bodyMedium,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${cues.size} cues  •  output: ${outputFormat.extension.uppercase()}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick= { openFile() },modifier=Modifier.weight(1f)) { Icon(Icons.Default.OpenInNew,null);Spacer(Modifier.width(6.dp));Text("Open") }
                    Button(onClick={saveFile()},enabled=cues.isNotEmpty(),modifier=Modifier.weight(1f)) { Icon(Icons.Default.Save,null);Spacer(Modifier.width(6.dp));Text("Save as") }
                }
                if(cues.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) {
                    Text("Open a subtitle file to start.\nSRT, ASS, SSA, VTT, MicroDVD.",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                } else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    itemsIndexed(cues) { index,cue -> CueRow(index,cue) { editingCue=cue } }
                }
            }
        }
    }
    editingCue?.let { current -> CueEditorDialog(current,onDismiss={editingCue=null},onSave={updated -> cues=cues.map { if(it===current) updated else it }.sortedBy { it.startMs };editingCue=null},onDelete={cues=cues.filterNot { it===current };editingCue=null}) }
}

@Composable
fun CueRow(index:Int,cue:Cue,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text("#${index+1}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)
                Text("${formatMs(cue.startMs)} → ${formatMs(cue.endMs)}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp)); Text(cue.text,style=MaterialTheme.typography.bodyMedium,maxLines=3,overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun CueEditorDialog(cue:Cue,onDismiss:()->Unit,onSave:(Cue)->Unit,onDelete:()->Unit) {
    var text by remember(cue) { mutableStateOf(cue.text) }
    var start by remember(cue) { mutableStateOf(cue.startMs.toString()) }
    var end by remember(cue) { mutableStateOf(cue.endMs.toString()) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Edit cue")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(start,{start=it},label={Text("Start (ms)")},singleLine=true)
        OutlinedTextField(end,{end=it},label={Text("End (ms)")},singleLine=true)
        OutlinedTextField(text,{text=it},label={Text("Text")},minLines=3)
    }},confirmButton={TextButton(onClick={val s=start.toLongOrNull()?:cue.startMs;val e=end.toLongOrNull()?:cue.endMs;onSave(Cue(s,e,text))}) { Text("Save") }},dismissButton={Row {
        TextButton(onClick=onDelete) { Text("Delete",color=MaterialTheme.colorScheme.error) }
        TextButton(onClick=onDismiss) { Text("Cancel") }
    }})
}

private fun formatMs(ms:Long):String {
    val h=ms/3600000;val m=(ms%3600000)/60000;val s=(ms%60000)/1000;val mill=ms%1000
    return if(h>0) "%d:%02d:%02d.%03d".format(h,m,s,mill) else "%02d:%02d.%03d".format(m,s,mill)
}
private fun queryDisplayName(context:Context,uri:Uri):String? {
    context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { cursor ->
        if(cursor.moveToFirst()) { val idx=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(idx>=0)return cursor.getString(idx) }
    };return null
}
