package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue

object SrtFormat {
    private val timeRegex = Regex("""(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})""")
    fun parse(content: String): List<Cue> {
        val cues = mutableListOf<Cue>()
        for (block in content.removePrefix("\uFEFF").split(Regex("""\r?\n\s*\r?\n"""))) {
            val lines = block.lines().filter { it.isNotBlank() }
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: continue
            val match = timeRegex.find(timeLine) ?: continue
            val start = toMs(match, 1); val end = toMs(match, 5)
            val text = lines.drop(lines.indexOf(timeLine) + 1).joinToString("\n")
            if (text.isNotBlank()) cues.add(Cue(start, end, text))
        }
        return cues.sortedBy { it.startMs }
    }
    fun serialize(cues: List<Cue>): String = buildString {
        cues.sortedBy { it.startMs }.forEachIndexed { i, cue ->
            append(i + 1).append('\n').append(formatTime(cue.startMs)).append(" --> ")
                .append(formatTime(cue.endMs)).append('\n').append(cue.text).append("\n\n")
        }
    }
    private fun toMs(m: MatchResult, i: Int): Long = m.groupValues[i].toLong() * 3600000 + m.groupValues[i+1].toLong() * 60000 + m.groupValues[i+2].toLong() * 1000 + m.groupValues[i+3].toLong()
    private fun formatTime(ms: Long): String = "%02d:%02d:%02d,%03d".format(ms/3600000, (ms%3600000)/60000, (ms%60000)/1000, ms%1000)
}
