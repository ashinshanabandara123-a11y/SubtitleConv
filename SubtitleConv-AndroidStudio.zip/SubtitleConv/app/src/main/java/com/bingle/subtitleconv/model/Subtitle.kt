package com.bingle.subtitleconv.model

data class Cue(val startMs: Long, val endMs: Long, val text: String)

enum class SubtitleFormat(val extension: String, val displayName: String) {
    SRT("srt", "SubRip (.srt)"), ASS("ass", "Advanced SubStation Alpha (.ass)"),
    SSA("ssa", "SubStation Alpha (.ssa)"), VTT("vtt", "WebVTT (.vtt)"),
    MICRODVD("sub", "MicroDVD (.sub)")
}
