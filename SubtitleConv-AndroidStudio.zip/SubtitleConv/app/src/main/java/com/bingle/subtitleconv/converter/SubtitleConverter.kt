package com.bingle.subtitleconv.converter

import com.bingle.subtitleconv.model.Cue
import com.bingle.subtitleconv.model.SubtitleFormat
import java.io.InputStream

object SubtitleConverter {
    fun detectFormat(content:String):SubtitleFormat {
        val c=content.removePrefix("\uFEFF")
        return when {
            c.contains("[Script Info]") || c.contains("[V4+ Styles]") || c.contains("Dialogue:") -> if(c.contains("ScriptType: v4.00+")) SubtitleFormat.ASS else SubtitleFormat.SSA
            c.startsWith("WEBVTT") -> SubtitleFormat.VTT
            c.contains("-->") && c.contains(Regex("""\d{2}:\d{2}:\d{2},\d{3}""")) -> SubtitleFormat.SRT
            c.contains(Regex("""\{\d+\}\{\d+\}""")) -> SubtitleFormat.MICRODVD
            else -> SubtitleFormat.SRT
        }
    }
    fun parse(inputStream:InputStream,hint:SubtitleFormat?=null):List<Cue> {
        val text=decodeBytes(inputStream.readBytes()); return when(hint?:detectFormat(text)) {
            SubtitleFormat.SRT -> SrtFormat.parse(text); SubtitleFormat.VTT -> VttFormat.parse(text)
            SubtitleFormat.ASS,SubtitleFormat.SSA -> AssFormat.parse(text); SubtitleFormat.MICRODVD -> MicroDvdFormat.parse(text)
        }
    }
    fun serialize(cues:List<Cue>,format:SubtitleFormat):String=when(format) {
        SubtitleFormat.SRT -> SrtFormat.serialize(cues); SubtitleFormat.VTT -> VttFormat.serialize(cues)
        SubtitleFormat.ASS,SubtitleFormat.SSA -> AssFormat.serialize(cues); SubtitleFormat.MICRODVD -> MicroDvdFormat.serialize(cues)
    }
    private fun decodeBytes(b:ByteArray):String=when {
        b.size>=3 && b[0]==0xEF.toByte() && b[1]==0xBB.toByte() && b[2]==0xBF.toByte() -> String(b,3,b.size-3,Charsets.UTF_8)
        b.size>=2 && b[0]==0xFF.toByte() && b[1]==0xFE.toByte() -> String(b,2,b.size-2,Charsets.UTF_16LE)
        b.size>=2 && b[0]==0xFE.toByte() && b[1]==0xFF.toByte() -> String(b,2,b.size-2,Charsets.UTF_16BE)
        else -> String(b,Charsets.UTF_8)
    }
}
