package com.axiom.subcake

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.axiom.subcake.model.SubtitleCue
import com.axiom.subcake.subtitles.SrtCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Accent = Color(0xFF7652F5)
private val Muted = Color(0xFF9699AC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SubcakeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubcakeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cues by remember { mutableStateOf(listOf(
        SubtitleCue(1, 1200, 3400, "Welcome to Subcake Reborn."),
        SubtitleCue(2, 4100, 6200, "Your subtitle editing starts here.")
    )) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var message by remember { mutableStateOf("Ready") }
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val importSubtitle = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val content = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Could not read file")
                }
                cues = SrtCodec.parse(content)
                message = "Imported ${cues.size} cues"
            }.onFailure { message = "Import failed: ${it.message}" }
        }
    }
    val importVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            message = "Video loaded"
        }
    }
    val exportSubtitle = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                        it.write(SrtCodec.encode(cues))
                    } ?: error("Could not write file")
                }
                message = "Subtitle exported"
            }.onFailure { message = "Export failed: ${it.message}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("SUBCAKE", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("subtitle studio", color = Muted, fontSize = 11.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { importSubtitle.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Default.FolderOpen, "Import subtitles")
                    }
                    IconButton(onClick = { exportSubtitle.launch("subtitles.srt") }) {
                        Icon(Icons.Default.Save, "Export subtitles")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { importVideo.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f)) {
                        Text("Open video")
                    }
                    OutlinedButton(onClick = { importSubtitle.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                        Text("Open SRT")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(205.dp).background(Color.Black, RoundedCornerShape(16.dp))) {
                    if (videoUri != null) {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SC", color = Accent, fontSize = 44.sp, fontWeight = FontWeight.Black)
                            Text("Open a video to preview", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SUBTITLE TRACK", fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                    Text("${cues.size} cues", color = Muted, fontSize = 12.sp)
                    IconButton(onClick = {
                        val next = (cues.maxOfOrNull { it.id } ?: 0L) + 1
                        cues = cues + SubtitleCue(next, 0, 2000, "New subtitle")
                    }) { Icon(Icons.Default.Add, "Add cue", tint = Accent) }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(cues, key = { it.id }) { cue ->
                        Column(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("#${cue.id}", color = Accent, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(10.dp))
                                Text("${SrtCodec.format(cue.startMs)} → ${SrtCodec.format(cue.endMs)}",
                                    color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                IconButton(onClick = { cues = cues.filterNot { it.id == cue.id } }) {
                                    Icon(Icons.Default.Delete, "Delete cue", tint = Muted)
                                }
                            }
                            var text by remember(cue.id, cue.text) { mutableStateOf(cue.text) }
                            BasicTextField(
                                value = text,
                                onValueChange = { value ->
                                    text = value
                                    cues = cues.map { if (it.id == cue.id) it.copy(text = value) else it }
                                },
                                textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 15.sp),
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                            )
                        }
                    }
                }
                Text(message, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
            }
        }
    }
}
