package com.axiom.subcake.model

data class SubtitleCue(
    val id: Long,
    val startMs: Long,
    val endMs: Long,
    val text: String
)
