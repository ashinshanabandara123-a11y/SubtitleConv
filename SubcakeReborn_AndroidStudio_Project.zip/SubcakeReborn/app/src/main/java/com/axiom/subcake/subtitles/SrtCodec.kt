package com.axiom.subcake.subtitles

import com.axiom.subcake.model.SubtitleCue

object SrtCodec {
    private val timestamp = Regex("(\\\\d{2}):(\\\\d{2}):(\\\\d{2})[,.](\\\\d{3})\\\\s*-->\\\\s*(\\\\d{2}):(\\\\d{2}):(\\\\d{2})[,.](\\\\d{3})")

    fun parse(source: String): List<SubtitleCue> {
        val normalized = source.removePrefix("\\uFEFF").replace("\\r\\n", "\\n").replace('\\r', '\\n')
        return normalized.trim().split(Regex("\\n\\\\s*\\n")).mapIndexedNotNull { index, block ->
            val lines = block.lines()
            val timeIndex = lines.indexOfFirst { timestamp.containsMatchIn(it) }
            if (timeIndex < 0) return@mapIndexedNotNull null
            val v = timestamp.find(lines[timeIndex])!!.groupValues
            fun ms(h: String, m: String, s: String, milli: String) =
                h.toLong() * 3_600_000 + m.toLong() * 60_000 + s.toLong() * 1_000 + milli.toLong()
            SubtitleCue(index.toLong() + 1, ms(v[1],v[2],v[3],v[4]), ms(v[5],v[6],v[7],v[8]),
                lines.drop(timeIndex + 1).joinToString("\\n").trim())
        }.sortedBy { it.startMs }
    }

    fun encode(cues: List<SubtitleCue>): String = cues.sortedBy { it.startMs }
        .mapIndexed { index, cue ->
            "${index + 1}\\n${format(cue.startMs)} --> ${format(cue.endMs)}\\n${cue.text}"
        }.joinToString("\\n\\n", postfix = if (cues.isNotEmpty()) "\\n" else "")

    fun format(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        return "%02d:%02d:%02d,%03d".format(
            t / 3_600_000, (t % 3_600_000) / 60_000, (t % 60_000) / 1_000, t % 1_000
        )
    }
}
