# Subcake Reborn

Android Studio starter project for a Subcake-style subtitle editor.

## Open
1. Unzip this project.
2. Open the `SubcakeReborn` folder in Android Studio.
3. Allow Gradle sync (JDK 17).
4. Run the `app` configuration on an Android 8.0+ device or emulator.

## Included
- Compose dark editor interface
- Import `.srt` subtitle files
- Parse and edit cue text
- Add and delete cues
- Export edited subtitles as `.srt`
- Select and play video with AndroidX Media3
- Launcher icon resources made from the supplied SC artwork

## Not implemented yet
ASS/SSA parsing and rendering, waveform/timeline editing, and FFmpeg-based hard-subtitle rendering. This is a functional MVP starter, not a complete feature-for-feature recreation of the discontinued Subcake app.
